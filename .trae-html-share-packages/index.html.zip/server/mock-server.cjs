// server/mock-server.cjs
const express = require('express')
const cors = require('cors')
const crypto = require('crypto')
const multer = require('multer')

const app = express()
app.use(cors())
app.use(express.json())

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 }
})

// 内存态：文件表 + 两步检测进度
const files = new Map()
const detectState = { step1: null, step2: null }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

// 演示用的三档结果
const SAMPLES = {
  1: {
    pass: {
      outcome: 'pass',
      message: '包装实物与生产任务单信息一致',
      anomalies: []
    },
    warning: {
      outcome: 'warning',
      message: '检测到 2 项信息不一致，请人工复核',
      anomalies: [
        {
          carrier: '封口贴',
          field: '生产批次号',
          expected: '20241113-A02',
          actual: '20241113-A01'
        },
        {
          carrier: '内盒',
          field: '有效期',
          expected: '2026-11-12',
          actual: '2025-11-12'
        }
      ]
    },
    failed: {
      outcome: 'failed',
      message: '图片模糊，部分关键信息无法识别',
      anomalies: [
        { carrier: '铝箔', field: '生产日期', desc: '未识别到该字段，请重新拍摄' },
        { carrier: '封口贴', field: '产品规格', desc: '文字模糊，识别置信度过低' }
      ]
    }
  },
  2: {
    pass: {
      outcome: 'pass',
      message: '电子生产任务单信息完整，校验通过',
      anomalies: []
    },
    warning: {
      outcome: 'warning',
      message: '检测到 1 项信息不一致',
      anomalies: [
        {
          carrier: '任务单第 2 页',
          field: '生产数量',
          expected: '1000',
          actual: '800'
        }
      ]
    },
    failed: {
      outcome: 'failed',
      message: '文件内容无法识别',
      anomalies: [{ carrier: '任务单第 1 页', field: '任务单编号', desc: '未识别到该字段' }]
    }
  }
}

// Mock：用企微 code 换用户信息 + 业务 token
app.post('/api/auth/wx-code', (req, res) => {
  const { code } = req.body
  console.log('[Mock] 收到 code:', code)

  res.json({
    token: 'mock-token-' + Date.now(),
    userId: 'zhangsan',
    userName: '张三',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=zhangsan'
  })
})

// Mock：JS-SDK 签名
app.get('/api/wework/jssdk-sign', (req, res) => {
  const { url } = req.query
  const nonceStr = Math.random().toString(36).slice(2)
  const timestamp = Math.floor(Date.now() / 1000)
  const ticket = 'mock-jsapi-ticket'
  const str = `jsapi_ticket=${ticket}&noncestr=${nonceStr}&timestamp=${timestamp}&url=${url}`
  const signature = crypto.createHash('sha1').update(str).digest('hex')

  res.json({
    corpId: 'wx1234567890',
    agentId: 1000002,
    timestamp,
    nonceStr,
    signature
  })
})

// 第一步：只上传文件
app.post('/api/detect/upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ code: 400, message: '未收到文件' })
  }
  await sleep(600)

  const fileId = 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8)
  const fileName = req.file.originalname || 'upload'
  files.set(fileId, { name: fileName, size: req.file.size, type: req.file.mimetype })

  console.log(`[Mock] 上传文件 ${fileName} (${req.file.size} bytes) → ${fileId}`)
  res.json({ code: 0, data: { fileId, fileName } })
})

// 第二步：点击「检测」后调用
app.post('/api/detect/check', async (req, res) => {
  const { step, fileId, mock } = req.body
  const s = Number(step)

  if (s !== 1 && s !== 2) {
    return res.status(400).json({ code: 400, message: 'step 参数不合法' })
  }
  if (!fileId || !files.has(fileId)) {
    return res.status(400).json({ code: 400, message: '文件不存在，请重新上传' })
  }
  if (s === 2 && detectState.step1?.result?.outcome !== 'pass') {
    return res.status(403).json({ code: 403, message: '请先完成第一步检测' })
  }

  await sleep(1500)

  // 默认通过；联调时传 mock=warning / mock=failed 可查看其他两档
  const outcome = ['pass', 'warning', 'failed'].includes(mock) ? mock : 'pass'
  const result = SAMPLES[s][outcome]

  detectState[`step${s}`] = {
    fileId,
    fileName: files.get(fileId).name,
    result
  }
  console.log(`[Mock] step${s} 检测结果：${outcome}`)
  res.json({ code: 0, data: result })
})

// 查询进度（刷新恢复）
app.get('/api/detect/status', (req, res) => {
  res.json({ code: 0, data: detectState })
})

// 调试：重置
app.post('/api/detect/reset', (req, res) => {
  detectState.step1 = null
  detectState.step2 = null
  res.json({ code: 0, data: detectState })
})

const PORT = 3000
app.listen(PORT, () => {
  console.log(`✅ Mock server running at http://localhost:${PORT}`)
  console.log('   前端访问 http://localhost:5173 即可（已配置 proxy）')
})
