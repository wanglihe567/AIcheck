import { create } from 'zustand'
import { request } from '@/api'
import { clearToken, getToken, setToken } from '@/utils/storage'

interface UserInfo {
  userId: string
  userName: string
  avatar: string
}

interface UserState {
  token: string | null
  userInfo: UserInfo | null
  isLoggedIn: boolean
  loginWithCode: (code: string) => Promise<void>
  logout: () => void
}

export const useUserStore = create<UserState>((set) => ({
  token: getToken(),
  userInfo: null,
  isLoggedIn: !!getToken(),

  loginWithCode: async (code: string) => {
    // 走统一 request 实例，读取 VITE_API_BASE_URL（开发环境指向 Mock 服务）
    const data: any = await request.post('/auth/wx-code', { code })
    setToken(data.token)
    set({
      token: data.token,
      userInfo: data as UserInfo,
      isLoggedIn: true
    })
  },

  logout: () => {
    clearToken()
    set({ token: null, userInfo: null, isLoggedIn: false })
  }
}))
