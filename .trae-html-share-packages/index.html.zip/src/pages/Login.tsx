import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useUserStore } from '@/store/useUserStore'

export default function Login() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const { loginWithCode } = useUserStore()
  const [code, setCode] = useState(searchParams.get('code') || '')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleLogin = async () => {
    if (!code.trim()) {
      setError('请输入 code 参数')
      return
    }
    setLoading(true)
    setError('')
    try {
      await loginWithCode(code.trim())
      navigate('/', { replace: true })
    } catch (e: any) {
      setError(e?.response?.data?.message || '登录失败，请检查 Mock 服务是否启动')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ padding: 24 }}>
      <h2 style={{ marginBottom: 8 }}>开发环境登录</h2>
      <p style={{ color: '#999', fontSize: 13, marginBottom: 24 }}>
        真实场景下由企微入口带 code 自动跳转，本地 Mock 时手动输入
      </p>

      <input
        value={code}
        onChange={(e) => setCode(e.target.value)}
        placeholder="输入 code 参数"
        style={{
          width: '100%',
          padding: '10px 12px',
          border: '1px solid #ddd',
          borderRadius: 6,
          fontSize: 14
        }}
      />

      {error && <p style={{ color: '#ff4d4f', fontSize: 13, marginTop: 12 }}>{error}</p>}

      <button
        onClick={handleLogin}
        disabled={loading}
        style={{
          width: '100%',
          marginTop: 20,
          padding: 12,
          background: loading ? '#ccc' : '#07c160',
          color: '#fff',
          border: 'none',
          borderRadius: 6,
          fontSize: 15,
          cursor: loading ? 'not-allowed' : 'pointer'
        }}
      >
        {loading ? '登录中...' : '登录'}
      </button>

      <p style={{ color: '#999', fontSize: 12, marginTop: 24, textAlign: 'center' }}>
        提示：运行 <code>node server/mock-server.js</code> 启动 Mock 服务
      </p>
    </div>
  )
}
