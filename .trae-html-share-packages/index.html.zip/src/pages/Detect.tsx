import { useEffect, useState } from 'react'
import { SafeArea, SpinLoading, Toast } from 'antd-mobile'
import DetectUploadCard from '@/components/DetectUploadCard'
import { checkDetect, fetchDetectStatus, uploadDetectFile } from '@/api/detect'
import type { DetectStep } from '@/api/detect'
import { useDetectStore } from '@/store/useDetectStore'
import { compressImage, isPdfFile, validateFile } from '@/utils/image'
import { isCanceled, pickFile, warmupWeworkSDK } from '@/utils/wework'
import type { PickSource } from '@/utils/wework'
import './detect.css'

/** 页面标题，按业务替换 */
const PAGE_TITLE = 'XXX检测'

export default function Detect() {
  const { step1, step2, setStep, resetStep, hydrate } = useDetectStore()
  const [initializing, setInitializing] = useState(true)

  // 进入页面先拉取后端进度，避免刷新后重新开始
  useEffect(() => {
    // 预热企微 JS-SDK，保证点击时已是就绪状态（iOS 需要同步可用的通道）
    warmupWeworkSDK()

    fetchDetectStatus()
      .then(hydrate)
      .catch(() => {
        /* 状态拉取失败不阻塞主流程，按空白状态处理 */
      })
      .finally(() => setInitializing(false))
  }, [hydrate])

  /** 上传文件（不检测） */
  const handlePick = async (step: DetectStep, source: PickSource) => {
    const allowPdf = step === 2
    try {
      const file = await pickFile(source, allowPdf ? 'image/*,application/pdf' : 'image/*')
      validateFile(file, allowPdf)

      const isPdf = isPdfFile(file)
      // PDF 不做压缩，图片压一下
      const uploadFile = isPdf ? file : await compressImage(file)

      const prev = step === 1 ? step1.preview : step2.preview
      if (prev.startsWith('blob:')) URL.revokeObjectURL(prev)

      setStep(step, {
        uploadStatus: 'uploading',
        uploadError: '',
        fileId: '',
        fileName: file.name,
        preview: isPdf ? '' : URL.createObjectURL(uploadFile),
        result: null
      })

      // 第一个模块重新上传时，第二个模块的进度失效
      if (step === 1) resetStep(2)

      const { fileId, fileName } = await uploadDetectFile(uploadFile)
      setStep(step, { uploadStatus: 'uploaded', fileId, fileName: fileName || file.name })
      Toast.show({ icon: 'success', content: '上传成功，可开始检测' })
    } catch (e) {
      if (isCanceled(e)) return
      const message = e instanceof Error ? e.message : '上传失败，请重试'
      setStep(step, { uploadStatus: 'idle', uploadError: message })
      Toast.show({ icon: 'fail', content: message })
    }
  }

  /** 点击「检测」 */
  const handleDetect = async (step: DetectStep) => {
    const current = step === 1 ? step1 : step2
    if (!current.fileId || current.detecting) return

    setStep(step, { detecting: true })
    Toast.show({ icon: 'loading', content: '检测中…', duration: 0 })

    try {
      // 开发环境可用 ?mock=warning / ?mock=failed 指定结果档位，便于验收
      const mock = import.meta.env.DEV
        ? new URLSearchParams(window.location.search).get('mock') || undefined
        : undefined
      const result = await checkDetect(step, current.fileId, mock)
      Toast.clear()
      setStep(step, { detecting: false, result })

      const tips = {
        pass: '一致通过',
        warning: '信息不一致预警',
        failed: '信息缺失 / 识别失败'
      } as const
      Toast.show({
        icon: result.outcome === 'pass' ? 'success' : 'fail',
        content: tips[result.outcome]
      })

      // 第一步结论变化时，第二步必须重做
      if (step === 1) resetStep(2)
    } catch (e) {
      Toast.clear()
      const message = e instanceof Error ? e.message : '检测失败，请重试'
      setStep(step, { detecting: false })
      Toast.show({ icon: 'fail', content: message })
    }
  }

  const step1Passed = step1.result?.outcome === 'pass'

  return (
    <div className="detect-page">
      <header className="detect-page__header">
        <h1 className="detect-page__title">{PAGE_TITLE}</h1>
        <p className="detect-page__subtitle">请依次上传文件并点击检测，完成两步检测</p>
      </header>

      {initializing ? (
        <div className="detect-page__loading">
          <SpinLoading color="primary" />
        </div>
      ) : (
        <main className="detect-page__body">
          <DetectUploadCard
            index={1}
            title="包装实物实拍图（封口贴、铝箔、内盒）检测"
            description="请拍摄封口贴、铝箔、内盒等包装实物图"
            uploadText="点击上传包装实物实拍图"
            state={step1}
            onPick={(source) => handlePick(1, source)}
            onDetect={() => handleDetect(1)}
          />

          <DetectUploadCard
            index={2}
            title="电子生产任务单（图片、PDF 文件）检测"
            description="第一步检测一致通过后，方可进行第二项检测"
            uploadText="点击上传电子生产任务单"
            allowPdf
            state={step2}
            disabled={!step1Passed}
            disabledText={
              step1.result ? '第一步检测未一致通过，请重新检测' : '请先完成第一步检测'
            }
            onPick={(source) => handlePick(2, source)}
            onDetect={() => handleDetect(2)}
          />
        </main>
      )}

      <SafeArea position="bottom" />
    </div>
  )
}
