import path from 'node:path'
import os from 'node:os'
import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'

// https://vite.dev/config/
// 同一份产物同时承载 PC 端（antd）与移动端（antd-mobile）：
// - PC 端所有请求走同源 /api、/files，由本服务器反代到后端（默认 127.0.0.1:8000）
// - 移动端通过 VITE_API_BASE_URL 直连接口（开发环境默认 Mock 服务 3000 端口）
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const target = env.VITE_PROXY_TARGET || 'http://127.0.0.1:8000'
  const proxy = {
    '/api': { target, changeOrigin: true },
    '/files': { target, changeOrigin: true }
  }

  return {
    plugins: [react()],
    // 缓存目录放到系统临时目录，避免 Desktop 目录写入受限导致依赖预构建失败
    cacheDir: path.join(os.tmpdir(), 'newagent-vite-cache'),
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, './src')
      }
    },
    server: {
      port: 5173,
      proxy
    },
    preview: {
      port: 4173,
      proxy
    }
  }
})
